/**
 * 
 */
package br.com.cenaculo.converter;

import br.com.cenaculo.model.RelTotais;

/**
 * @author Priscila.Andersen
 *
 */
public class RelDetalheConverter {

	public static RelTotais convertJson() {
		RelTotais relDetalhado = new RelTotais();

		relDetalhado.setMensagem("Consulta Executada.");
		relDetalhado.setStatus(Boolean.TRUE);
		return relDetalhado;

	}

}
