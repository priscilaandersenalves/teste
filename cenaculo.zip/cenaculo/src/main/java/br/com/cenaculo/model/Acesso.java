package br.com.cenaculo.model;

public class Acesso {
	private Boolean status;
	private String mensagem;
	private String login;
	private String senha;

	/**
	 * @param login
	 * @param senha
	 */
	public Acesso(String login, String senha) {
		super();
		this.login = login;
		this.senha = senha;
	}

	/**
	 * @param status
	 * @param mensagem
	 * @param login
	 * @param senha
	 */
	public Acesso(Boolean status, String mensagem, String login, String senha) {
		super();
		this.status = status;
		this.mensagem = mensagem;
		this.login = login;
		this.senha = senha;
	}

	/**
	 * @param status
	 * @param mensagem
	 */
	public Acesso(Boolean status, String mensagem) {
		super();
		this.status = status;
		this.mensagem = mensagem;
	}

	public Acesso() {
		super();
	}
	/**
	 * @return the status
	 */
	public final Boolean getStatus() {
		return status;
	}
	/**
	 * @param status
	 *            the status to set
	 */
	public final void setStatus(Boolean status) {
		this.status = status;
	}
	/**
	 * @return the mensagem
	 */
	public final String getMensagem() {
		return mensagem;
	}
	/**
	 * @param mensagem
	 *            the mensagem to set
	 */
	public final void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}
	/**
	 * @return the login
	 */
	public final String getLogin() {
		return login;
	}
	/**
	 * @param login
	 *            the login to set
	 */
	public final void setLogin(String login) {
		this.login = login;
	}
	/**
	 * @return the senha
	 */
	public final String getSenha() {
		return senha;
	}
	/**
	 * @param senha
	 *            the senha to set
	 */
	public final void setSenha(String senha) {
		this.senha = senha;
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Acesso [status=" + status + ", mensagem=" + mensagem
				+ ", login=" + login + ", senha=" + senha + "]";
	}

}
