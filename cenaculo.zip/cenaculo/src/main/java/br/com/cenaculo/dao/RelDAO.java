package br.com.cenaculo.dao;

import br.com.cenaculo.model.Cabecalho;
import br.com.cenaculo.model.ParamConsulta;
import br.com.cenaculo.model.RelDetalhado;
import br.com.cenaculo.model.RelTotais;

public interface RelDAO {
	/**
	 * Faz a busca do relatorio Detalhado de totais
	 * 
	 * @param param
	 * 
	 * @return
	 */
	RelTotais getRelTotais(ParamConsulta param);
	/**
	 * Faz a busca das informacoes do cabeçalho do relatorio
	 * 
	 * @param param
	 * @return
	 */
	Cabecalho getCabecalho(ParamConsulta param);

	/**
	 * Faz a consulta das informações do Relatorio Detalhado de transacoes
	 * 
	 * @param paramConsulta
	 * @return
	 */
	RelDetalhado getRelDetalhado(ParamConsulta paramConsulta);

}
