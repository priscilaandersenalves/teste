/**
 * 
 */
package br.com.cenaculo.model;

import java.util.Date;

import br.com.cenaculo.util.FormatterGlobal;

/**
 * @author Priscila.Andersen
 *
 */
public class ParamConsulta {
	private String dataIni;
	private String dataFim;
	private String horaIni;
	private String horaFim;
	private String loja;
	private String idUsuario;
	private String tipoBaixaTecnica;
	private String login;
	private String senha;

	/**
	 * @param login
	 * @param senha
	 */
	public ParamConsulta(String login, String senha) {
		super();
		this.login = login;
		this.senha = senha;
	}
	/**
	 * @param dataIni
	 * @param dataFim
	 * @param horaIni
	 * @param horaFim
	 * @param loja
	 * @param idUsuario
	 * @param tipoBaixaTecnica
	 */
	public ParamConsulta(String dataIni, String horaIni, String dataFim,
			String horaFim, String loja, String idUsuario,
			String tipoBaixaTecnica) {
		super();
		this.dataIni = (dataIni == null || dataIni == ""
				? FormatterGlobal.converterBR(new Date())
				: dataIni);
		this.horaIni = (horaIni == null || horaIni == "" ? "00:00" : horaIni);
		this.dataFim = (dataFim == null || dataFim == ""
				? FormatterGlobal.converterBR(new Date())
				: dataFim);
		this.horaFim = (horaFim == null || horaFim == "" ? "23:59" : horaFim);
		this.loja = (loja == null || loja == "" ? null : loja);
		this.idUsuario = (idUsuario == null || idUsuario == ""
				? null
				: idUsuario);
		this.tipoBaixaTecnica = (tipoBaixaTecnica == null
				|| tipoBaixaTecnica == "" ? null : tipoBaixaTecnica);
	}
	/**
	 * @return the dataIni
	 */
	public final String getDataIni() {
		return dataIni;
	}
	/**
	 * @param dataIni
	 *            the dataIni to set
	 */
	public final void setDataIni(String dataIni) {
		this.dataIni = dataIni;
	}
	/**
	 * @return the dataFim
	 */
	public final String getDataFim() {
		return dataFim;
	}
	/**
	 * @return the horaIni
	 */
	public final String getHoraIni() {
		return horaIni;
	}
	/**
	 * @param horaIni
	 *            the horaIni to set
	 */
	public final void setHoraIni(String horaIni) {
		this.horaIni = horaIni;
	}
	/**
	 * @return the horaFim
	 */
	public final String getHoraFim() {
		return horaFim;
	}
	/**
	 * @param horaFim
	 *            the horaFim to set
	 */
	public final void setHoraFim(String horaFim) {
		this.horaFim = horaFim;
	}
	/**
	 * @param dataFim
	 *            the dataFim to set
	 */
	public final void setDataFim(String dataFim) {
		this.dataFim = dataFim;
	}
	/**
	 * @return the loja
	 */
	public final String getLoja() {
		return loja;
	}
	/**
	 * @param loja
	 *            the loja to set
	 */
	public final void setLoja(String loja) {
		this.loja = loja;
	}
	/**
	 * @return the idUsuario
	 */
	public final String getIdUsuario() {
		return idUsuario;
	}
	/**
	 * @param idUsuario
	 *            the idUsuario to set
	 */
	public final void setIdUsuario(String idUsuario) {
		this.idUsuario = idUsuario;
	}
	/**
	 * @return the tipoBaixaTecnica
	 */
	public final String getTipoBaixaTecnica() {
		return tipoBaixaTecnica;
	}
	/**
	 * @param tipoBaixaTecnica
	 *            the tipoBaixaTecnica to set
	 */
	public final void setTipoBaixaTecnica(String tipoBaixaTecnica) {
		this.tipoBaixaTecnica = tipoBaixaTecnica;
	}

	/**
	 * @return the login
	 */
	public final String getLogin() {
		return login;
	}
	/**
	 * @param login
	 *            the login to set
	 */
	public final void setLogin(String login) {
		this.login = login;
	}
	/**
	 * @return the senha
	 */
	public final String getSenha() {
		return senha;
	}
	/**
	 * @param senha
	 *            the senha to set
	 */
	public final void setSenha(String senha) {
		this.senha = senha;
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ParamConsulta [dataIni=" + dataIni + ", dataFim=" + dataFim
				+ ", horaIni=" + horaIni + ", horaFim=" + horaFim + ", loja="
				+ loja + ", idUsuario=" + idUsuario + ", tipoBaixaTecnica="
				+ tipoBaixaTecnica + "]";
	}

}
