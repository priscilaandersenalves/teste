/**
 * 
 */
package br.com.cenaculo.model;

import br.com.cenaculo.util.FormatterGlobal;

/**
 * @author Priscila.Andersen
 *
 */
public class DetalhesTransacao {

	private String bandeira;
	private Integer nsu;
	private String data;
	private String hora;
	private String formaPag;
	private String codResposta;
	private String codTransacao;
	private String tipoTransacao;
	private String statusTransacao;
	private String valor;
	private Integer qtdePag;
	private String codAutorizacao;

	/**
	 * @return the codAutorizacao
	 */
	public final String getCodAutorizacao() {
		return codAutorizacao;
	}
	/**
	 * @param codAutorizacao
	 *            the codAutorizacao to set
	 */
	public final void setCodAutorizacao(String codAutorizacao) {
		this.codAutorizacao = codAutorizacao;
	}
	/**
	 * @return the nsu
	 */
	public final Integer getNsu() {
		return nsu;
	}
	/**
	 * @param nsu
	 *            the nsu to set
	 */
	public final void setNsu(Integer nsu) {
		this.nsu = nsu;
	}
	/**
	 * @return the data
	 */
	public final String getData() {
		return data;
	}
	/**
	 * @param data
	 *            the data to set
	 */
	public final void setData(String data) {
		this.data = data;
	}
	/**
	 * @return the hora
	 */
	public final String getHora() {
		return hora;
	}
	/**
	 * @param hora
	 *            the hora to set
	 */
	public final void setHora(String hora) {
		this.hora = hora;
	}
	/**
	 * @return the formaPag
	 */
	public final String getFormaPag() {
		return formaPag;
	}
	/**
	 * @param formaPag
	 *            the formaPag to set
	 */
	public final void setFormaPag(String formaPag) {
		this.formaPag = (formaPag != null
				? FormatterGlobal.removerAcentos(formaPag.toUpperCase())
				: null);
	}
	/**
	 * @return the codResposta
	 */
	public final String getCodResposta() {
		return codResposta;
	}
	/**
	 * @param codResposta
	 *            the codResposta to set
	 */
	public final void setCodResposta(String codResposta) {
		this.codResposta = codResposta;
	}
	/**
	 * @return the codTransacao
	 */
	public final String getCodTransacao() {
		return codTransacao;
	}
	/**
	 * @param codTransacao
	 *            the codTransacao to set
	 */
	public final void setCodTransacao(String codTransacao) {
		this.codTransacao = codTransacao;
	}
	/**
	 * @return the tipoTransacao
	 */
	public final String getTipoTransacao() {
		return tipoTransacao;
	}
	/**
	 * @param tipoTransacao
	 *            the tipoTransacao to set
	 */
	public final void setTipoTransacao(String tipoTransacao) {
		this.tipoTransacao = tipoTransacao;
	}
	/**
	 * @return the statusTransacao
	 */
	public final String getStatusTransacao() {
		return statusTransacao;
	}
	/**
	 * @param statusTransacao
	 *            the statusTransacao to set
	 */
	public final void setStatusTransacao(String statusTransacao) {
		this.statusTransacao = (statusTransacao != null
				? FormatterGlobal.removerAcentos(statusTransacao.toUpperCase())
				: null);;
	}
	/**
	 * @return the valor
	 */
	public final String getValor() {
		return valor;
	}
	/**
	 * @param valor
	 *            the valor to set
	 */
	public final void setValor(String valor) {
		this.valor = valor;
	}
	/**
	 * @return the bandeira
	 */
	public final String getBandeira() {
		return bandeira;
	}
	/**
	 * @param bandeira
	 *            the bandeira to set
	 */
	public final void setBandeira(String bandeira) {
		this.bandeira = bandeira;
	}

	/**
	 * @return the qtdePag
	 */
	public final Integer getQtdePag() {
		return qtdePag;
	}
	/**
	 * @param qtdePag
	 *            the qtdePag to set
	 */
	public final void setQtdePag(Integer qtdePag) {
		this.qtdePag = qtdePag;
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DetalhesTransacao [nsu=" + nsu + ", data=" + data + ", hora="
				+ hora + ", formaPag=" + formaPag + ", codResposta="
				+ codResposta + ", codTransacao=" + codTransacao
				+ ", tipoTransacao=" + tipoTransacao + ", statusTransacao="
				+ statusTransacao + ", valor=" + valor + ", bandeira="
				+ bandeira + ", qtdePag=" + qtdePag + ", codAutorizacao="
				+ codAutorizacao + "]";
	}

}
