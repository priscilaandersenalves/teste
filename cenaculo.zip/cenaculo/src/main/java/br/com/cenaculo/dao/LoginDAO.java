/**
 * 
 */
package br.com.cenaculo.dao;

import br.com.cenaculo.model.AcessoMobile;
import br.com.cenaculo.model.ParamConsulta;

/**
 * @author Priscila.Andersen
 *
 */
public interface LoginDAO {
	/**
	 * Consulta o acesso ao sistema mobile
	 * 
	 * @param paramConsulta
	 * @return
	 */

	AcessoMobile getAcessoMobile(ParamConsulta paramConsulta);
}
