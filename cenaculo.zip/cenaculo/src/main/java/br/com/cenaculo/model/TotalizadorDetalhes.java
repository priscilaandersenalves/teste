package br.com.cenaculo.model;

public class TotalizadorDetalhes {
	private Integer qtdeTotal;
	private Double valorTotal;
	/**
	 * @return the qtdeTotal
	 */
	public final Integer getQtdeTotal() {
		return qtdeTotal;
	}
	/**
	 * @param qtdeTotal
	 *            the qtdeTotal to set
	 */
	public final void setQtdeTotal(Integer qtdeTotal) {
		this.qtdeTotal = qtdeTotal;
	}
	/**
	 * @return the valorTotal
	 */
	public final Double getValorTotal() {
		return valorTotal;
	}
	/**
	 * @param valorTotal
	 *            the valorTotal to set
	 */
	public final void setValorTotal(Double valorTotal) {
		this.valorTotal = valorTotal;
	}

}
