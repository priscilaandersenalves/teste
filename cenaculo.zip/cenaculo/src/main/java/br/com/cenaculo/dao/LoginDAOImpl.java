/**
 * 
 */
package br.com.cenaculo.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import br.com.cenaculo.model.AcessoMobile;
import br.com.cenaculo.model.ParamConsulta;
import br.com.cenaculo.util.ConnectionFactory;
import br.com.cenaculo.util.Query;

/**
 * @author Priscila.Andersen
 *
 */
public class LoginDAOImpl implements LoginDAO {
	private Query query = new Query();
	private ConnectionFactory con = new ConnectionFactory();

	@Override
	public AcessoMobile getAcessoMobile(ParamConsulta paramConsulta) {
		AcessoMobile mobile = null;
		Statement stmt = null;
		ResultSet rs = null;
		Connection conn = con.conectarSQL();

		String sql = query.getLogin(paramConsulta);
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				mobile = new AcessoMobile();
				mobile.setIdEmpresa(rs.getInt("idEmpresa"));
				mobile.setIdLoja(rs.getInt("idLoja"));
				mobile.setIdUsuario(rs.getInt("idUsuario"));
				mobile.setSenhaMobile(rs.getString("senhaMobile"));
			}
		} catch (SQLException e) {
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		} finally {
			if (stmt != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return mobile;
	}

}
