package br.com.cenaculo.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import br.com.cenaculo.converter.CabecalhoConverter;
import br.com.cenaculo.model.Cabecalho;
import br.com.cenaculo.model.DetalhesTotal;
import br.com.cenaculo.model.DetalhesTransacao;
import br.com.cenaculo.model.ParamConsulta;
import br.com.cenaculo.model.RecorrenciaCliente;
import br.com.cenaculo.model.RelDetalhado;
import br.com.cenaculo.model.RelTotais;
import br.com.cenaculo.model.TotalGeral;
import br.com.cenaculo.util.ConnectionFactory;
import br.com.cenaculo.util.FormatterGlobal;
import br.com.cenaculo.util.Query;

public class RelDAOImpl implements RelDAO {
	private Query query = new Query();
	private ConnectionFactory con = new ConnectionFactory();

	@Override
	public Cabecalho getCabecalho(ParamConsulta param) {

		Cabecalho cabecalho = null;
		String query_cabecalho = query.buscaCabecalho(param);
		System.out.println("Cabecalho" + query_cabecalho);

		Statement stmt = null;
		ResultSet rs = null;
		Connection conn = con.conectarSQL();

		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query_cabecalho);
			while (rs.next()) {
				cabecalho = CabecalhoConverter.convertJson(rs, param);
			}
		} catch (SQLException e) {
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		} finally {
			if (stmt != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return cabecalho;
	}

	@Override
	public RelTotais getRelTotais(ParamConsulta param) {
		RelTotais totais = new RelTotais();

		Statement stmt = null;

		List<DetalhesTotal> listTotal = new ArrayList<DetalhesTotal>();

		populaTotais(param, totais, stmt, listTotal);

		TotalGeral totalGeral = populaTotalGeral(param, totais, stmt);
		if (totalGeral == null) {
			totais.setMensagem("ERRO AO PROCESSAR O RELATORIO DE TOTAIS");
			totais.setStatus(Boolean.FALSE);
		} else {
			totais.setTotalGeral(totalGeral);
		}

		RecorrenciaCliente recorrencia = populaRecorrencia(param, totais, stmt);
		if (recorrencia == null) {
			totais.setMensagem("ERRO AO PROCESSAR A RECORRENCIA DO CLIENTE");
			totais.setStatus(Boolean.FALSE);
		} else {
			totais.setRecorrenciaCliente(recorrencia);
		}

		return totais;
	}

	private RecorrenciaCliente populaRecorrencia(ParamConsulta param,
			RelTotais totais, Statement stmt) {

		Connection conn = con.conectarSQL();

		ResultSet rs;
		RecorrenciaCliente rc = null;
		try {

			stmt = conn.createStatement();
			rs = stmt.executeQuery(query.totalRecorrencia(param));
			int rec_1 = 0;
			int rec_2 = 0;
			int rec_3 = 0;

			while (rs.next()) {
				if (rs.getString("numero_cartao") != null) {
					if (rs.getInt("qtde") == 1) {
						rec_1++;
					} else if (rs.getInt("qtde") == 2) {
						rec_2++;
					} else if (rs.getInt("qtde") >= 3) {
						rec_3++;
					}
				}
			}

			rc = new RecorrenciaCliente();
			rc.setUmaCompra(rec_1);
			rc.setDuasCompras(rec_2);
			rc.setTresOuMaisCompras(rec_3);

			return rc;

		} catch (SQLException e) {
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
			return null;
		} finally {
			if (stmt != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}

	private TotalGeral populaTotalGeral(ParamConsulta param, RelTotais totais,
			Statement stmt) {
		Connection conn = con.conectarSQL();

		ResultSet rs;
		TotalGeral tg = null;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query.totalGeral(param));
			int tCanc = 0;
			Double tValor = 0d;
			int qtdeG = 0;
			Double valorG = 0d;

			while (rs.next()) {
				if ("9111".equals(rs.getString("tipo_transacao"))
						&& "SSS".equals(rs.getString("status_transacao"))
						&& "000".equals(rs.getString("codresposta"))) {
					tCanc += rs.getInt("qtde");
					tValor += rs.getDouble("total");
				}
				qtdeG += rs.getInt("qtde");
				valorG += rs.getDouble("total");
			}
			tg = new TotalGeral();
			tg.setQtdeCancel(tCanc);
			tg.setTotalCancel(FormatterGlobal.convertValor(tValor));
			tg.setQtdeGeral(qtdeG);
			tg.setTotalGeral(FormatterGlobal.convertValor(valorG));

			return tg;
		} catch (SQLException e) {
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
			return null;
		} finally {
			if (stmt != null) {
				try {

					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	private void populaTotais(ParamConsulta param, RelTotais totais,
			Statement stmt, List<DetalhesTotal> listTotal) {
		Connection conn = con.conectarSQL();

		ResultSet rs;
		DetalhesTotal dt;
		try {

			stmt = conn.createStatement();
			rs = stmt.executeQuery(query.buscasTotais(param));

			while (rs.next()) {
				dt = new DetalhesTotal();
				dt.setBandeira(rs.getString("bandeira"));
				dt.setFormaPag(rs.getString("formaPag"));
				dt.setQtdePag(rs.getInt("qtdePag"));
				dt.setValorTotPag(FormatterGlobal
						.convertValor(rs.getDouble("valorTotPag")));

				listTotal.add(dt);
			}

			ResultSet rs2 = stmt.executeQuery(query.buscarTotalizador(param));
			while (rs2.next()) {
				dt = new DetalhesTotal();
				dt.setBandeira("TOTAL");
				dt.setFormaPag(rs2.getString("formaPag"));
				dt.setQtdePag(rs2.getInt("qtdePag"));
				dt.setValorTotPag(FormatterGlobal
						.convertValor(rs2.getDouble("valorTotPag")));

				listTotal.add(dt);
			}

			Map<String, List<DetalhesTotal>> map = new HashMap<String, List<DetalhesTotal>>();
			// Ordenar formas de pagamentos
			ordenarFormaPag(listTotal, map);

			if (listTotal.isEmpty()) {
				totais.setDetalhesTotal(null);
				totais.setMensagem("NENHUM PAGAMENTO NO PERIODO INFORMADO");
				totais.setStatus(Boolean.FALSE);
			} else {
				totais.setDetalhesTotal(map);

				// Mensagem de sucesso
				totais.setStatus(Boolean.TRUE);
				totais.setMensagem("Transacao OK");
			}
		} catch (SQLException e) {

			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		} finally {
			if (stmt != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	private void ordenarFormaPag(List<DetalhesTotal> listTotal,
			Map<String, List<DetalhesTotal>> map) {

		for (DetalhesTotal dst : listTotal) {
			String key = dst.getFormaPag();

			dst.setFormaPag(null);
			if (map.containsKey(key)) {
				List<DetalhesTotal> list = map.get(key);
				list.add(dst);
			} else {
				List<DetalhesTotal> list = new ArrayList<DetalhesTotal>();
				list.add(dst);
				map.put(key, list);
			}
		}
	}

	@Override
	public RelDetalhado getRelDetalhado(ParamConsulta param) {
		RelDetalhado relTrans = new RelDetalhado();

		Statement stmt = null;

		List<DetalhesTransacao> listTransacao = new ArrayList<DetalhesTransacao>();

		Connection conn = con.conectarSQL();

		ResultSet rs;
		DetalhesTransacao dtrans;
		int qdteCancel = 0;
		int qtdeGeral = 0;
		int qtdeD = 0;
		int qtdeC = 0;
		int qtdeV = 0;

		Double totalD = 0d;
		Double totalC = 0d;
		Double totalV = 0d;
		Double totalCancel = 0d;
		Double totalGeral = 0d;

		try {

			stmt = conn.createStatement();
			rs = stmt.executeQuery(query.consultaTransacoes(param));

			while (rs.next()) {
				dtrans = new DetalhesTransacao();
				dtrans.setNsu(rs.getInt("nsu_transacao"));
				dtrans.setData(FormatterGlobal.converterBR(rs.getDate("DATA")));
				dtrans.setHora(rs.getString("hora"));
				dtrans.setFormaPag(rs.getString("transacao"));
				dtrans.setStatusTransacao(rs.getString("status_transacao"));
				dtrans.setValor(
						FormatterGlobal.convertValor(rs.getDouble("valor")));
				dtrans.setBandeira(rs.getString("bandeira"));

				if ("9111".equals(rs.getString("tipo_transacao"))
						&& "SSS".equals(rs.getString("status_transacao"))
						&& "000".equals(rs.getString("codresposta"))) {

					qdteCancel++;
					totalCancel += rs.getDouble("valor");

				}
				qtdeGeral++;
				totalGeral += rs.getDouble("valor");

				if (dtrans.getFormaPag().contains("DEBITO")) {
					qtdeD++;
					totalD += rs.getDouble("valor");
				} else if (dtrans.getFormaPag().contains("CREDITO")) {
					qtdeC++;
					totalC += rs.getDouble("valor");
				} else {
					qtdeV++;
					totalV += rs.getDouble("valor");
				}

				listTransacao.add(dtrans);
			}

			// prenche o totalizador
			TotalGeral totalizador = new TotalGeral();
			totalizador.setQtdeCancel(qdteCancel);
			totalizador
					.setTotalCancel(FormatterGlobal.convertValor(totalCancel));
			totalizador.setQtdeGeral(qtdeGeral);
			totalizador.setTotalGeral(FormatterGlobal.convertValor(totalGeral));

			relTrans.setTotalGeral(totalizador);
			DetalhesTransacao detD = new DetalhesTransacao();
			DetalhesTransacao detC = new DetalhesTransacao();
			DetalhesTransacao detV = new DetalhesTransacao();

			// Add Total por forma de pagamento
			if (qtdeD > 0) {
				detD.setBandeira("TOTAL_DEBITO");
				detD.setQtdePag(qtdeD);
				detD.setFormaPag("DEBITO");
				detD.setValor(FormatterGlobal.convertValor(totalD));
			}
			if (qtdeC > 0) {
				detC.setBandeira("TOTAL_CREDITO");
				detC.setQtdePag(qtdeC);
				detC.setFormaPag("CREDITO");
				detC.setValor(FormatterGlobal.convertValor(totalC));
			}
			if (qtdeV > 0) {
				detV.setBandeira("TOTAL_VALE");
				detV.setQtdePag(qtdeV);
				detV.setFormaPag("VALE");
				detV.setValor(FormatterGlobal.convertValor(totalV));
			}

			Map<String, Map<String, List<DetalhesTransacao>>> map = organizaTransacoes(
					listTransacao, detD, detC, detV);

			if (listTransacao.isEmpty()) {
				relTrans.setMensagem("NENHUM PAGAMENTO NO PERIODO INFORMADO");
				relTrans.setStatus(Boolean.FALSE);
				relTrans.setDetalhesTrans(null);
			} else {

				relTrans.setDetalhesTransMap(map);
				// Mensagem de sucesso
				relTrans.setStatus(Boolean.TRUE);
				relTrans.setMensagem("Transacao OK");
			}

		} catch (SQLException e) {
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		} finally {
			if (stmt != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return relTrans;
	}

	/**
	 * @param listTransacao
	 * @return
	 */
	private Map<String, Map<String, List<DetalhesTransacao>>> organizaTransacoes(
			List<DetalhesTransacao> listTransacao, DetalhesTransacao detD,
			DetalhesTransacao detC, DetalhesTransacao detV) {

		List<DetalhesTransacao> listD = new ArrayList<DetalhesTransacao>();
		List<DetalhesTransacao> listC = new ArrayList<DetalhesTransacao>();
		List<DetalhesTransacao> listV = new ArrayList<DetalhesTransacao>();
		Map<String, List<DetalhesTransacao>> mapD = new HashMap<String, List<DetalhesTransacao>>();
		Map<String, List<DetalhesTransacao>> mapC = new HashMap<String, List<DetalhesTransacao>>();
		Map<String, List<DetalhesTransacao>> mapV = new HashMap<String, List<DetalhesTransacao>>();

		for (DetalhesTransacao detalhesTransacao : listTransacao) {
			if (detalhesTransacao.getFormaPag().contains("DEBITO")) {
				listD.add(detalhesTransacao);
			} else if (detalhesTransacao.getFormaPag().contains("CREDITO")) {
				listC.add(detalhesTransacao);
			} else {
				listV.add(detalhesTransacao);
			}
		}

		ordenarBandeira(listD, mapD, detD);
		ordenarBandeira(listC, mapC, detC);
		ordenarBandeira(listV, mapV, detV);

		Map<String, Map<String, List<DetalhesTransacao>>> map = new HashMap<String, Map<String, List<DetalhesTransacao>>>();
		if (listD.size() > 0)
			map.put("DEBITO", mapD);
		if (listC.size() > 0)
			map.put("CREDITO", mapC);
		if (listV.size() > 0)
			map.put("VALE", mapV);

		return map;
	}

	private void ordenarBandeira(List<DetalhesTransacao> listTransacao,
			Map<String, List<DetalhesTransacao>> mapD,
			DetalhesTransacao total) {

		for (DetalhesTransacao dst : listTransacao) {
			String key = dst.getBandeira();

			dst.setFormaPag(null);
			if (mapD.containsKey(key)) {
				List<DetalhesTransacao> list = mapD.get(key);
				list.add(dst);
			} else {
				List<DetalhesTransacao> list = new ArrayList<DetalhesTransacao>();
				list.add(dst);
				mapD.put(key, list);
			}
		}
		List<DetalhesTransacao> totalFinal = new ArrayList<DetalhesTransacao>();
		totalFinal.add(total);
		mapD.put(total.getBandeira(), totalFinal);

	}

	public RelDetalhado getRelTransacao(ParamConsulta paramConsulta) {
		RelDetalhado relTrans = new RelDetalhado();

		Statement stmt = null;

		List<DetalhesTransacao> listTransacao = new ArrayList<DetalhesTransacao>();

		Connection conn = con.conectarSQL();

		ResultSet rs;
		DetalhesTransacao dtrans;

		try {

			stmt = conn.createStatement();
			rs = stmt.executeQuery(query.consultaTransacoes(paramConsulta));
			while (rs.next()) {
				dtrans = new DetalhesTransacao();
				dtrans.setNsu(rs.getInt("nsu_transacao"));
				dtrans.setData(FormatterGlobal.converterBR(rs.getDate("DATA")));
				dtrans.setHora(rs.getString("hora"));
				dtrans.setFormaPag(rs.getString("transacao"));
				dtrans.setStatusTransacao(rs.getString("status_transacao"));
				dtrans.setValor(
						FormatterGlobal.convertValor(rs.getDouble("valor")));
				dtrans.setBandeira(rs.getString("bandeira"));
				dtrans.setCodAutorizacao(rs.getString("codAutorizacao"));
				listTransacao.add(dtrans);
			}

			if (listTransacao.isEmpty()) {
				relTrans.setMensagem("NENHUM PAGAMENTO NO PERIODO INFORMADO");
				relTrans.setStatus(Boolean.FALSE);
				relTrans.setDetalhesTrans(null);
			} else {
				relTrans.setDetalhesTrans(listTransacao);
				// Mensagem de sucesso
				relTrans.setStatus(Boolean.TRUE);
				relTrans.setMensagem("Transacao OK");
			}

		} catch (SQLException e) {
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		} finally {
			if (stmt != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return relTrans;
	}

}
