/**
 * 
 */
package br.com.cenaculo.controller;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.ws.rs.PathParam;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;

import br.com.cenaculo.dao.LoginDAOImpl;
import br.com.cenaculo.dao.RelDAOImpl;
import br.com.cenaculo.model.Acesso;
import br.com.cenaculo.model.AcessoMobile;
import br.com.cenaculo.model.Cabecalho;
import br.com.cenaculo.model.ParamConsulta;
import br.com.cenaculo.model.RelDetalhado;
import br.com.cenaculo.model.RelTotais;

/**
 * @author Priscila.Andersen
 *
 */
@Controller
public class RelController {

	private static final Logger logger = LoggerFactory
			.getLogger(RelController.class);

	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);

		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG,
				DateFormat.LONG, locale);

		String formattedDate = dateFormat.format(date);

		model.addAttribute("serverTime", formattedDate);

		return "home";
	}

	@RequestMapping(value = "/Login", method = RequestMethod.GET)
	@ResponseBody
	public String getLogin(@PathParam("login") String login,
			@PathParam("senha") String senha) {
		Acesso acesso = new Acesso(Boolean.FALSE, "Acesso Negado");
		LoginDAOImpl daoImpl = new LoginDAOImpl();
		ParamConsulta paramConsulta = new ParamConsulta(login, senha);

		AcessoMobile acessoMobile = new AcessoMobile();
		acessoMobile = daoImpl.getAcessoMobile(paramConsulta);
		if (acessoMobile != null) {
			acesso = new Acesso(Boolean.TRUE, "Login efetuado com sucesso");
		}
		Gson retorno = new Gson();
		return retorno.toJson(acesso);
	}

	@RequestMapping(value = "/RelDetalhado", method = RequestMethod.GET)
	@ResponseBody
	public String getRelDetalhado(@PathParam("dataIni") String dataIni,
			@PathParam("horaIni") String horaIni,
			@PathParam("dataFim") String dataFim,
			@PathParam("horaFim") String horaFim,
			@PathParam("tipoBaixaTecnica") String tipoBaixaTecnica,
			@PathParam("loja") String loja,
			@PathParam("idUsuario") String idUsuario) {

		ParamConsulta paramConsulta = new ParamConsulta(dataIni, horaIni,
				dataFim, horaFim, loja, idUsuario, tipoBaixaTecnica);
		RelDAOImpl dao = new RelDAOImpl();

		RelDetalhado reDet = new RelDetalhado();
		Cabecalho cabecalho = new Cabecalho();
		cabecalho = dao.getCabecalho(paramConsulta);
		if (cabecalho == null) {
			reDet.setMensagem("Erro na Consulta do Cabecalho");
			reDet.setStatus(Boolean.FALSE);
		} else {
			reDet = dao.getRelDetalhado(paramConsulta);
			reDet.setCabecalho(cabecalho);
		}

		Gson retorno = new Gson();
		return retorno.toJson(reDet);
	}

	@RequestMapping(value = "/RelTotais", method = RequestMethod.GET)
	@ResponseBody
	public String getRelTotais(@PathParam("dataIni") String dataIni,
			@PathParam("horaIni") String horaIni,
			@PathParam("dataFim") String dataFim,
			@PathParam("horaFim") String horaFim,
			@PathParam("tipoBaixaTecnica") String tipoBaixaTecnica,
			@PathParam("loja") String loja,
			@PathParam("idUsuario") String idUsuario, Locale locale,
			Model model) {

		ParamConsulta paramConsulta = new ParamConsulta(dataIni, horaIni,
				dataFim, horaFim, loja, idUsuario, tipoBaixaTecnica);

		RelDAOImpl dao = new RelDAOImpl();
		RelTotais relTotais = new RelTotais();
		Cabecalho cabecalho = new Cabecalho();
		cabecalho = dao.getCabecalho(paramConsulta);
		if (cabecalho == null) {
			relTotais.setMensagem("Erro na Consulta do Cabecalho");
			relTotais.setStatus(Boolean.FALSE);
		} else {
			relTotais = dao.getRelTotais(paramConsulta);
			relTotais.setCabecalho(cabecalho);
		}

		Gson retorno = new Gson();
		return retorno.toJson(relTotais);
	}

	@RequestMapping(value = "/RelTransacao", method = RequestMethod.GET)
	@ResponseBody
	public String getRelTransacao(@PathParam("dataIni") String dataIni,
			@PathParam("horaIni") String horaIni,
			@PathParam("dataFim") String dataFim,
			@PathParam("horaFim") String horaFim,
			@PathParam("tipoBaixaTecnica") String tipoBaixaTecnica,
			@PathParam("loja") String loja,
			@PathParam("idUsuario") String idUsuario) {

		ParamConsulta paramConsulta = new ParamConsulta(dataIni, horaIni,
				dataFim, horaFim, loja, idUsuario, tipoBaixaTecnica);
		RelDAOImpl dao = new RelDAOImpl();

		RelDetalhado relTrans = new RelDetalhado();
		Cabecalho cabecalho = new Cabecalho();
		cabecalho = dao.getCabecalho(paramConsulta);
		if (cabecalho == null) {
			relTrans.setMensagem("Erro na Consulta do Cabecalho");
			relTrans.setStatus(Boolean.FALSE);
		} else {
			relTrans = dao.getRelTransacao(paramConsulta);
			relTrans.setCabecalho(cabecalho);
		}

		Gson retorno = new Gson();
		return retorno.toJson(relTrans);
	}

}
