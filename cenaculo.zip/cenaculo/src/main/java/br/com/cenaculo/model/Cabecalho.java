package br.com.cenaculo.model;

public class Cabecalho {

	private String estabelecimento;

	private String endereco;

	private String cidade;

	private Integer pos;

	private String datetime;

	public Cabecalho() {
	}

	/**
	 * @return the estabelecimento
	 */
	public final String getEstabelecimento() {
		return estabelecimento;
	}

	/**
	 * @param estabelecimento
	 *            the estabelecimento to set
	 */
	public final void setEstabelecimento(String estabelecimento) {
		this.estabelecimento = estabelecimento;
	}

	/**
	 * @return the endereco
	 */
	public final String getEndereco() {
		return endereco;
	}

	/**
	 * @param endereco
	 *            the endereco to set
	 */
	public final void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	/**
	 * @return the cidade
	 */
	public final String getCidade() {
		return cidade;
	}

	/**
	 * @param cidade
	 *            the cidade to set
	 */
	public final void setCidade(String cidade) {
		this.cidade = cidade;
	}

	/**
	 * @return the pos
	 */
	public final Integer getPos() {
		return pos;
	}

	/**
	 * @param pos
	 *            the pos to set
	 */
	public final void setPos(Integer pos) {
		this.pos = pos;
	}

	/**
	 * @return the datetime
	 */
	public final String getDatetime() {
		return datetime;
	}

	/**
	 * @param datetime
	 *            the datetime to set
	 */
	public final void setDatetime(String datetime) {
		this.datetime = datetime;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((cidade == null) ? 0 : cidade.hashCode());
		result = prime * result
				+ ((datetime == null) ? 0 : datetime.hashCode());
		result = prime * result
				+ ((endereco == null) ? 0 : endereco.hashCode());
		result = prime * result
				+ ((estabelecimento == null) ? 0 : estabelecimento.hashCode());
		result = prime * result + ((pos == null) ? 0 : pos.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cabecalho other = (Cabecalho) obj;
		if (cidade == null) {
			if (other.cidade != null)
				return false;
		} else if (!cidade.equals(other.cidade))
			return false;
		if (datetime == null) {
			if (other.datetime != null)
				return false;
		} else if (!datetime.equals(other.datetime))
			return false;
		if (endereco == null) {
			if (other.endereco != null)
				return false;
		} else if (!endereco.equals(other.endereco))
			return false;
		if (estabelecimento == null) {
			if (other.estabelecimento != null)
				return false;
		} else if (!estabelecimento.equals(other.estabelecimento))
			return false;
		if (pos == null) {
			if (other.pos != null)
				return false;
		} else if (!pos.equals(other.pos))
			return false;
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Cabecalho [estabelecimento=" + estabelecimento + ", endereco="
				+ endereco + ", cidade=" + cidade + ", pos=" + pos
				+ ", datetime=" + datetime + "]";
	}

}
