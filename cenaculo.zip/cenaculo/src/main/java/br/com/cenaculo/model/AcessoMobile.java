/**
 * 
 */
package br.com.cenaculo.model;

/**
 * @author Priscila.Andersen
 *
 */
public class AcessoMobile {
	private Integer idUsuario;
	private Integer idLoja;
	private Integer idEmpresa;
	private String senhaMobile;
	/**
	 * @return the idUsuario
	 */
	public final Integer getIdUsuario() {
		return idUsuario;
	}
	/**
	 * @param idUsuario
	 *            the idUsuario to set
	 */
	public final void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}
	/**
	 * @return the idLoja
	 */
	public final Integer getIdLoja() {
		return idLoja;
	}
	/**
	 * @param idLoja
	 *            the idLoja to set
	 */
	public final void setIdLoja(Integer idLoja) {
		this.idLoja = idLoja;
	}
	/**
	 * @return the idEmpresa
	 */
	public final Integer getIdEmpresa() {
		return idEmpresa;
	}
	/**
	 * @param idEmpresa
	 *            the idEmpresa to set
	 */
	public final void setIdEmpresa(Integer idEmpresa) {
		this.idEmpresa = idEmpresa;
	}
	/**
	 * @return the senhaMobile
	 */
	public final String getSenhaMobile() {
		return senhaMobile;
	}
	/**
	 * @param senhaMobile
	 *            the senhaMobile to set
	 */
	public final void setSenhaMobile(String senhaMobile) {
		this.senhaMobile = senhaMobile;
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AcessoMobile [idUsuario=" + idUsuario + ", idLoja=" + idLoja
				+ ", idEmpresa=" + idEmpresa + ", senhaMobile=" + senhaMobile
				+ "]";
	}

}
