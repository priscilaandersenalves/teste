/**
 * 
 */
package br.com.cenaculo.model;

import java.util.List;
import java.util.Map;

import com.google.gson.annotations.SerializedName;

/**
 * @author Priscila.Andersen
 *
 */
public class RelTotais {
	// mensagem do retorno
	private Boolean status;
	private String mensagem;

	@SerializedName("CABECALHO")
	private Cabecalho cabecalho;

	@SerializedName("FORMAS_PAGAMENTO")
	private Map<String, List<DetalhesTotal>> detalhesTotal;

	@SerializedName("TOTAL_GERAL")
	private TotalGeral totalGeral;

	@SerializedName("RECORRENCIA_CLIENTE")
	private RecorrenciaCliente recorrenciaCliente;

	/**
	 * 
	 */
	public RelTotais() {
		super();
	}

	/**
	 * @param status
	 * @param mensagem
	 */
	public RelTotais(Boolean status, String mensagem) {
		super();
		this.status = status;
		this.mensagem = mensagem;
	}

	/**
	 * @return the status
	 */
	public final Boolean getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public final void setStatus(Boolean status) {
		this.status = status;
	}

	/**
	 * @return the mensagem
	 */
	public final String getMensagem() {
		return mensagem;
	}

	/**
	 * @param mensagem
	 *            the mensagem to set
	 */
	public final void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	/**
	 * @return the cabecalho
	 */
	public final Cabecalho getCabecalho() {
		return cabecalho;
	}

	/**
	 * @param cabecalho
	 *            the cabecalho to set
	 */
	public final void setCabecalho(Cabecalho cabecalho) {
		this.cabecalho = cabecalho;
	}

	/**
	 * @return the detalhesTotal
	 */
	public final Map<String, List<DetalhesTotal>> getDetalhesTotal() {
		return detalhesTotal;
	}

	/**
	 * @param detalhesTotal
	 *            the detalhesTotal to set
	 */
	public final void setDetalhesTotal(
			Map<String, List<DetalhesTotal>> detalhesTotal) {
		this.detalhesTotal = detalhesTotal;
	}

	/**
	 * @return the totalGeral
	 */
	public final TotalGeral getTotalGeral() {
		return totalGeral;
	}

	/**
	 * @param totalGeral
	 *            the totalGeral to set
	 */
	public final void setTotalGeral(TotalGeral totalGeral) {
		this.totalGeral = totalGeral;
	}

	/**
	 * @return the recorrenciaCliente
	 */
	public final RecorrenciaCliente getRecorrenciaCliente() {
		return recorrenciaCliente;
	}

	/**
	 * @param recorrenciaCliente
	 *            the recorrenciaCliente to set
	 */
	public final void setRecorrenciaCliente(
			RecorrenciaCliente recorrenciaCliente) {
		this.recorrenciaCliente = recorrenciaCliente;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "RelTotais [status=" + status + ", mensagem=" + mensagem
				+ ", cabecalho=" + cabecalho + ", detalhesTotal="
				+ detalhesTotal + ", totalGeral=" + totalGeral
				+ ", recorrenciaCliente=" + recorrenciaCliente + "]";
	}

}
