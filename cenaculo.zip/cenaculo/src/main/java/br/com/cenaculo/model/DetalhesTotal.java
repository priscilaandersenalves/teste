package br.com.cenaculo.model;

import java.util.List;

import br.com.cenaculo.util.FormatterGlobal;

public class DetalhesTotal {
	private String formaPag;
	private Integer qtdePag;
	private String valorTotPag;
	private String bandeira;
	private List<TotalizadorDetalhes> total;

	private Integer qtdeTotal;
	private Double valorTotal;

	/**
	 * @return the qtdeTotal
	 */
	public final Integer getQtdeTotal() {
		return qtdeTotal;
	}
	/**
	 * @param qtdeTotal
	 *            the qtdeTotal to set
	 */
	public final void setQtdeTotal(Integer qtdeTotal) {
		this.qtdeTotal = qtdeTotal;
	}
	/**
	 * @return the valorTotal
	 */
	public final Double getValorTotal() {
		return valorTotal;
	}
	/**
	 * @param valorTotal
	 *            the valorTotal to set
	 */
	public final void setValorTotal(Double valorTotal) {
		this.valorTotal = valorTotal;
	}
	/**
	 * @return the formaPag
	 */
	public final String getFormaPag() {
		return formaPag;
	}
	/**
	 * @param formaPag
	 *            the formaPag to set
	 */
	public final void setFormaPag(String formaPag) {
		this.formaPag = (formaPag != null
				? FormatterGlobal.removerAcentos(formaPag.toUpperCase())
				: null);
	}
	/**
	 * @return the qtdePag
	 */
	public final Integer getQtdePag() {
		return qtdePag;
	}
	/**
	 * @param qtdePag
	 *            the qtdePag to set
	 */
	public final void setQtdePag(Integer qtdePag) {
		this.qtdePag = qtdePag;
	}
	/**
	 * @return the valorTotPag
	 */
	public final String getValorTotPag() {
		return valorTotPag;
	}
	/**
	 * @param valorTotPag
	 *            the valorTotPag to set
	 */
	public final void setValorTotPag(String valorTotPag) {
		this.valorTotPag = valorTotPag;
	}
	/**
	 * @return the bandeira
	 */
	public final String getBandeira() {
		return bandeira;
	}
	/**
	 * @param bandeira
	 *            the bandeira to set
	 */
	public final void setBandeira(String bandeira) {
		this.bandeira = FormatterGlobal.removerAcentos(bandeira.toUpperCase());;
	}
	/**
	 * @return the total
	 */
	public final List<TotalizadorDetalhes> getTotal() {
		return total;
	}
	/**
	 * @param total
	 *            the total to set
	 */
	public final void setTotal(List<TotalizadorDetalhes> total) {
		this.total = total;
	}

}
