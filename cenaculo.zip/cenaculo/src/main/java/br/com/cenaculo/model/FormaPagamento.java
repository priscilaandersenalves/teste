package br.com.cenaculo.model;

public enum FormaPagamento {
	DEBITO, CREDITO, VOUCHER, OUTRO
}
