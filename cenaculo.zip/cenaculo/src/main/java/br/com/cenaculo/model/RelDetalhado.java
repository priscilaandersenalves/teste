/**
 * 
 */
package br.com.cenaculo.model;

import java.util.List;
import java.util.Map;

import com.google.gson.annotations.SerializedName;

/**
 * @author Priscila.Andersen
 *
 */
public class RelDetalhado {

	// mensagem do retorno
	private Boolean status;
	private String mensagem;

	@SerializedName("CABECALHO")
	private Cabecalho cabecalho;

	@SerializedName("FORMA_PAGAMENTO")
	private List<DetalhesTransacao> detalhesTrans;

	@SerializedName("FORMAS_PAGAMENTO")
	private Map<String, Map<String, List<DetalhesTransacao>>> detalhesTransMap;

	@SerializedName("TOTAL_GERAL")
	private TotalGeral totalGeral;

	/**
	 * 
	 */
	public RelDetalhado() {
		super();
	}

	/**
	 * @param status
	 * @param mensagem
	 */
	public RelDetalhado(Boolean status, String mensagem) {
		super();
		this.status = status;
		this.mensagem = mensagem;
	}

	/**
	 * @return the status
	 */
	public final Boolean getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public final void setStatus(Boolean status) {
		this.status = status;
	}

	/**
	 * @return the mensagem
	 */
	public final String getMensagem() {
		return mensagem;
	}

	/**
	 * @param mensagem
	 *            the mensagem to set
	 */
	public final void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	/**
	 * @return the cabecalho
	 */
	public final Cabecalho getCabecalho() {
		return cabecalho;
	}

	/**
	 * @param cabecalho
	 *            the cabecalho to set
	 */
	public final void setCabecalho(Cabecalho cabecalho) {
		this.cabecalho = cabecalho;
	}

	/**
	 * @return the detalhesTrans
	 */
	public final List<DetalhesTransacao> getDetalhesTrans() {
		return detalhesTrans;
	}

	/**
	 * @param detalhesTrans
	 *            the detalhesTrans to set
	 */
	public final void setDetalhesTrans(List<DetalhesTransacao> detalhesTrans) {
		this.detalhesTrans = detalhesTrans;
	}

	/**
	 * @return the detalhesTransMap
	 */
	public final Map<String, Map<String, List<DetalhesTransacao>>> getDetalhesTransMap() {
		return detalhesTransMap;
	}

	/**
	 * @param detalhesTransMap
	 *            the detalhesTransMap to set
	 */
	public final void setDetalhesTransMap(
			Map<String, Map<String, List<DetalhesTransacao>>> detalhesTransMap) {
		this.detalhesTransMap = detalhesTransMap;
	}

	/**
	 * @return the totalGeral
	 */
	public final TotalGeral getTotalGeral() {
		return totalGeral;
	}

	/**
	 * @param totalGeral
	 *            the totalGeral to set
	 */
	public final void setTotalGeral(TotalGeral totalGeral) {
		this.totalGeral = totalGeral;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "RelDetalhado [status=" + status + ", mensagem=" + mensagem
				+ ", cabecalho=" + cabecalho + ", detalhesTrans="
				+ detalhesTrans + ", detalhesTransMap=" + detalhesTransMap
				+ ", totalGeral=" + totalGeral + "]";
	}

}
