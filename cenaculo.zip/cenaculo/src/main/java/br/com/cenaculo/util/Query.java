/**
 * 
 */
package br.com.cenaculo.util;

import br.com.cenaculo.model.ParamConsulta;

/**
 * @author Priscila.Andersen
 *
 */
public class Query {

	public String buscaCabecalho(ParamConsulta param) {
		String isMasterUser = "(SELECT masterUser FROM usuarios WHERE idusuario = "
				+ param.getIdUsuario() + ")";

		String query_cabecalho = " SELECT top 1 "
				+ " ce.Razao_Social as estabelecimento, ce.endereco + ' - ' + ce.bairro as endereco, "
				+ " ce.cidade + '-' + ce.estado as cidade, clt.codterminal as pos, "
				+ " Cast(clt.loja AS NVARCHAR) + ' - ' + cl.nome_loja AS loja "
				+ " FROM dbo.cielo_log_transacoes AS clt "
				+ " 	lEFT OUTER JOIN dbo.cadastro_loja AS cl ON clt.loja = cl.loja "
				+ " 	LEFT OUTER JOIN dbo.cadastro_empresa AS ce ON clt.empresa = ce.empresa "
				+ " 	LEFT JOIN dbo.acesso_usuario AS au ON au.idloja = clt.loja "
				+ " 	AND au.idempresa = clt.empresa AND (au.idUsuario = "
				+ param.getIdUsuario() + " OR " + isMasterUser + "= 1) "
				+ "WHERE " + " ( " + param.getLoja() + " = 0 OR clt.loja = "
				+ param.getLoja() + ") ";
		return query_cabecalho;
	}

	public String consultaTransacoes(final ParamConsulta param) {
		String isMasterUser = "(SELECT masterUser FROM usuarios WHERE idusuario = "
				+ param.getIdUsuario() + ")";

		String query = "SELECT distinct   "
				+ "  	fet.zerosAEsquerda(clt.nsu_transacao, 6) AS nsu_transacao,  "
				+ "  	Cast(clt.data_transacao AS DATE)    AS DATA,  "
				+ "  	clt.hora,  " + "       ttr.Descricao AS transacao,  "
				+ "  	clt.codresposta,  " + " 	   tipo_transacao, "
				+ "  	clt.status_transacao as codTransacao, "
				+ "  	stt.Descricao AS status_transacao,  "
				+ "  	Cast(CONVERT(DECIMAL(18, 2), Cast(clt.valor AS INT)) / 100 AS  DECIMAL(18, 2)) AS  valor,  "
				+ "  	clt.bandeira, " + "  	clt.codautorizacao	"
				+ " FROM   dbo.cielo_log_transacoes AS clt "
				+ " 		   INNER JOIN fet.tipo_transacao AS ttr "
				+ " 				ON ttr.ID = clt.tipo_transacao "
				+ " 		   INNER JOIN fet.tipo_leitura_cartao AS tlc "
				+ " 				ON tlc.ID = clt.TipoLeituraCartao "
				+ " 		   INNER JOIN fet.status_transacao AS stt "
				+ " 				ON stt.ID = clt.status_transacao "
				+ " 		   INNER JOIN fet.tipo_cartao AS tct "
				+ " 				ON tct.ID = clt.tipocartao "
				+ " 		   LEFT OUTER JOIN dbo.cadastro_loja AS cl  "
				+ " 						ON clt.loja = cl.loja  "
				+ " 		   LEFT OUTER JOIN dbo.cadastro_empresa AS ce  "
				+ " 						ON clt.empresa = ce.empresa  "
				+ " 		   LEFT JOIN dbo.acesso_usuario AS au  "
				+ " 				   ON au.idloja = clt.loja  "
				+ " 					  AND au.idempresa = clt.empresa "
				+ " 					  AND (au.idUsuario = "
				+ param.getIdUsuario() + " OR " + isMasterUser + "= 1) "
				+ "WHERE clt.[tipo_transacao] != " + param.getTipoBaixaTecnica()
				+ " AND ( " + param.getLoja() + " = 0 OR clt.loja = "
				+ param.getLoja() + ") "
				+ " AND ( ( clt.data_transacao BETWEEN '" + param.getDataIni();

		if (param.getHoraIni() != null) {
			query += " " + param.getHoraIni() + ":00' ";
		}
		query += " AND  '" + param.getDataFim();

		if (param.getHoraFim() != null) {
			query += " " + param.getHoraFim() + ":59' ";
		}

		query += "  ) " + "OR ( '" + param.getDataIni() + "' IS NULL OR '"
				+ param.getDataFim() + "' IS NULL ) ) "
				+ " AND clt.bandeira is not null AND clt.codautorizacao is not null ";

		query += " ORDER  BY transacao , clt.bandeira, nsu_transacao desc  ";
		System.out.println("consultaTransacoes  =>  " + query);
		return query;
	}

	public String buscasTotais(ParamConsulta param) {
		String isMasterUser = "(SELECT masterUser FROM usuarios WHERE idusuario = "
				+ param.getIdUsuario() + ")";

		String query = " select distinct(ttr.Descricao) AS formaPag, "
				+ " count(clt.bandeira) as qtdePag,  "
				+ " sum(Cast(CONVERT(DECIMAL(18, 2), Cast(clt.valor AS INT)) / 100 AS 	DECIMAL(18, 2)) ) AS valorTotPag, "
				+ " clt.bandeira " + " FROM   dbo.cielo_log_transacoes AS clt "
				+ " 	   INNER JOIN fet.tipo_transacao AS ttr "
				+ " 		ON ttr.ID = clt.tipo_transacao "
				+ " 	   LEFT JOIN dbo.acesso_usuario AS au  "
				+ " 			   ON au.idloja = clt.loja  "
				+ " 				  AND au.idempresa = clt.empresa "
				+ " 		  	AND (au.idUsuario = " + param.getIdUsuario()
				+ " OR " + isMasterUser + "= 1) "

				+ "WHERE clt.[tipo_transacao] != " + param.getTipoBaixaTecnica()
				+ " AND ( " + param.getLoja() + " = 0 OR clt.loja = "
				+ param.getLoja() + ") "
				+ "AND ( ( clt.data_transacao BETWEEN '" + param.getDataIni();

		if (param.getHoraIni() != null) {
			query += " " + param.getHoraIni() + ":00' ";
		}
		query += " AND  '" + param.getDataFim();

		if (param.getHoraFim() != null) {
			query += " " + param.getHoraFim() + ":59' ";
		}

		query += "  ) " + "OR ( '" + param.getDataIni() + "' IS NULL OR '"
				+ param.getDataFim() + "' IS NULL ) ) "
				+ " AND clt.bandeira is not null AND clt.codautorizacao is not null ";

		query += " group By ttr.Descricao,  clt.bandeira  "
				+ " order by  ttr.Descricao,  clt.bandeira ";
		System.out.println("buscasTotais   => " + query);
		return query;
	}

	public String buscarTotalizador(ParamConsulta param) {
		String isMasterUser = "(SELECT masterUser FROM usuarios WHERE idusuario = "
				+ param.getIdUsuario() + ")";

		String query = " select distinct(ttr.Descricao) AS formaPag, "
				+ " count(clt.bandeira) as qtdePag,  "
				+ " sum(Cast(CONVERT(DECIMAL(18, 2), Cast(clt.valor AS INT)) / 100 AS 	DECIMAL(18, 2)) ) AS valorTotPag "
				+ " FROM   dbo.cielo_log_transacoes AS clt "
				+ " 	   INNER JOIN fet.tipo_transacao AS ttr "
				+ " 		ON ttr.ID = clt.tipo_transacao "
				+ " 	   LEFT JOIN dbo.acesso_usuario AS au  "
				+ " 			   ON au.idloja = clt.loja  "
				+ " 				  AND au.idempresa = clt.empresa "
				+ " 		  	AND (au.idUsuario = " + param.getIdUsuario()
				+ " OR " + isMasterUser + "= 1) "

				+ "WHERE clt.[tipo_transacao] != " + param.getTipoBaixaTecnica()
				+ " AND ( " + param.getLoja() + " = 0 OR clt.loja = "
				+ param.getLoja() + ") "
				+ "AND ( ( clt.data_transacao BETWEEN '" + param.getDataIni();

		if (param.getHoraIni() != null) {
			query += " " + param.getHoraIni() + ":00' ";
		}
		query += " AND  '" + param.getDataFim();

		if (param.getHoraFim() != null) {
			query += " " + param.getHoraFim() + ":59' ";
		}
		query += "  ) " + "OR ( '" + param.getDataIni() + "' IS NULL OR '"
				+ param.getDataFim() + "' IS NULL ) ) "
				+ " AND clt.bandeira is not null AND clt.codautorizacao is not null  ";
		query += " group By ttr.Descricao  " + " order by  ttr.Descricao ";
		System.out.println("buscarTotalizador   => " + query);
		return query;

	}

	public String totalGeral(ParamConsulta param) {
		String isMasterUser = "(SELECT masterUser FROM usuarios WHERE idusuario = "
				+ param.getIdUsuario() + ")";
		String query = "SELECT  SUM(Cast(CONVERT(DECIMAL(18, 2), Cast(clt.valor AS INT)) / 100 AS  DECIMAL(18, 2)) ) AS total, "
				+ " count(nsu_transacao) as qtde, "
				+ " clt.tipo_transacao, clt.codresposta, clt.status_transacao "
				+ " FROM   dbo.cielo_log_transacoes AS clt "
				+ "LEFT JOIN dbo.acesso_usuario AS au  "
				+ " 			   ON au.idloja = clt.loja  "
				+ " 				  AND au.idempresa = clt.empresa "
				+ " 		  	AND (au.idUsuario = " + param.getIdUsuario()
				+ " OR " + isMasterUser + "= 1) "
				+ "WHERE clt.[tipo_transacao] != " + param.getTipoBaixaTecnica()
				+ " AND ( " + param.getLoja() + " = 0 OR clt.loja = "
				+ param.getLoja() + ") "
				+ "AND ( ( clt.data_transacao BETWEEN '" + param.getDataIni();

		if (param.getHoraIni() != null) {
			query += " " + param.getHoraIni() + ":00' ";
		}
		query += " AND  '" + param.getDataFim();

		if (param.getHoraFim() != null) {
			query += " " + param.getHoraFim() + ":59' ";
		}

		query += "  ) " + "OR ( '" + param.getDataIni() + "' IS NULL OR '"
				+ param.getDataFim() + "' IS NULL ) ) "
				+ " AND clt.bandeira is not null AND clt.codautorizacao is not null ";

		query += " group By tipo_transacao, clt.codresposta , status_transacao;";
		System.out.println("totalGeral   =>  " + query);
		return query;

	}

	public String totalRecorrencia(ParamConsulta param) {
		String isMasterUser = "(SELECT masterUser FROM usuarios WHERE idusuario = "
				+ param.getIdUsuario() + ")";

		String query = "SELECT distinct " + " clt.codterminal,  "
				+ " Cast(clt.data_transacao AS DATE) AS data,  "
				+ " clt.numero_cartao,  Count(numero_cartao) as qtde "
				+ " FROM   dbo.cielo_log_transacoes AS clt "
				+ "LEFT JOIN dbo.acesso_usuario AS au  "
				+ " 			   ON au.idloja = clt.loja  "
				+ " 				  AND au.idempresa = clt.empresa "
				+ " 		  	AND (au.idUsuario = " + param.getIdUsuario()
				+ " OR " + isMasterUser + "= 1) "
				+ "WHERE clt.[tipo_transacao] != " + param.getTipoBaixaTecnica()
				+ " AND ( " + param.getLoja() + " = 0 OR clt.loja = "
				+ param.getLoja() + ") "
				+ "AND ( ( clt.data_transacao BETWEEN '" + param.getDataIni();

		if (param.getHoraIni() != null) {
			query += " " + param.getHoraIni() + ":00' ";
		}
		query += " AND  '" + param.getDataFim();

		if (param.getHoraFim() != null) {
			query += " " + param.getHoraFim() + ":59' ";
		}

		query += "  ) " + "OR ( '" + param.getDataIni() + "' IS NULL OR '"
				+ param.getDataFim() + "' IS NULL ) ) "
				+ " AND clt.bandeira is not null AND clt.codautorizacao is not null ";

		query += " GROUP BY  clt.codterminal, clt.data_transacao , clt.numero_cartao WITH ROLLUP "
				+ " order by clt.numero_cartao ";
		System.out.println("totalRecorrencia   =>  " + query);
		return query;
	}

	public String getLogin(ParamConsulta paramConsulta) {
		return "SELECT  idUsuario, idLoja, idEmpresa, senhaMobile  FROM dbo.acesso_mobile"
				+ " where idLoja = " + paramConsulta.getLogin()
				+ " and senhaMobile = '" + paramConsulta.getSenha() + "' ";
	}
}
