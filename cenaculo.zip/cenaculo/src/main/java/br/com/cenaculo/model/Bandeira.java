/**
 * 
 */
package br.com.cenaculo.model;

/**
 * @author Priscila.Andersen
 *
 */
public enum Bandeira {
	VISA, MASTERCARD, MAESTRO, VISA_ELECTRON;

}
