/**
 * 
 */
package br.com.cenaculo.model;

/**
 * @author Priscila.Andersen
 *
 */
public class TotalGeral {

	private Integer qtdeCancel;
	private String totalCancel;
	private Integer qtdeGeral;
	private String totalGeral;

	/**
	 * 
	 */
	public TotalGeral() {
		super();
	}

	/**
	 * @param qtdeCancel
	 * @param totalCancel
	 * @param qtdeGeral
	 * @param totalGeral
	 */
	public TotalGeral(Integer qtdeCancel, String totalCancel, Integer qtdeGeral,
			String totalGeral) {
		super();
		this.qtdeCancel = qtdeCancel;
		this.totalCancel = totalCancel;
		this.qtdeGeral = qtdeGeral;
		this.totalGeral = totalGeral;
	}

	/**
	 * @return the qtdeCancel
	 */
	public final Integer getQtdeCancel() {
		return qtdeCancel;
	}

	/**
	 * @param qtdeCancel
	 *            the qtdeCancel to set
	 */
	public final void setQtdeCancel(Integer qtdeCancel) {
		this.qtdeCancel = qtdeCancel;
	}

	/**
	 * @return the totalCancel
	 */
	public final String getTotalCancel() {
		return totalCancel;
	}

	/**
	 * @param totalCancel
	 *            the totalCancel to set
	 */
	public final void setTotalCancel(String totalCancel) {
		this.totalCancel = totalCancel;
	}

	/**
	 * @return the qtdeGeral
	 */
	public final Integer getQtdeGeral() {
		return qtdeGeral;
	}

	/**
	 * @param qtdeGeral
	 *            the qtdeGeral to set
	 */
	public final void setQtdeGeral(Integer qtdeGeral) {
		this.qtdeGeral = qtdeGeral;
	}

	/**
	 * @return the totalGeral
	 */
	public final String getTotalGeral() {
		return totalGeral;
	}

	/**
	 * @param totalGeral
	 *            the totalGeral to set
	 */
	public final void setTotalGeral(String totalGeral) {
		this.totalGeral = totalGeral;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TotalGeral [qtdeCancel=" + qtdeCancel + ", totalCancel="
				+ totalCancel + ", qtdeGeral=" + qtdeGeral + ", totalGeral="
				+ totalGeral + "]";
	}

}
