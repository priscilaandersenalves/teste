
package br.com.cenaculo.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * @author Priscila.Andersen
 *
 */
public class ConnectionFactory {
	public void getConnection() {
		try {
			/*
			 * Dados Conexao Homologacao
			 * 
			 * String database = "MPFPODB1";
			 */

			String host = "54.164.96.181";
			String user = "user_mpf";
			String pass = "zaq12wsx";
			String database = "MPFPODB1_DUMP";// Producao
			String portNumber = "1433";

			String url = "jdbc:sqlserver://" + host + ":" + portNumber
					+ ";databaseName=" + database;
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver")
					.newInstance();
			DriverManager.getConnection(url, user, pass);
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (InstantiationException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (IllegalAccessException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}

	public Connection conectarSQL() {
		Connection conn = null;
		try {

			String host = "54.164.96.181";
			String user = "user_mpf";
			String pass = "zaq12wsxc";
			String database = "MPFPODB1_DUMP";
			String portNumber = "1433";

			String url = "jdbc:sqlserver://" + host + ":" + portNumber
					+ ";databaseName=" + database;
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver")
					.newInstance();
			conn = DriverManager.getConnection(url, user, pass);
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (InstantiationException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (IllegalAccessException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return conn;
	}
}
