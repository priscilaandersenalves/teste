/**
 * 
 */
package br.com.cenaculo.converter;

import java.sql.ResultSet;
import java.sql.SQLException;

import br.com.cenaculo.model.Cabecalho;
import br.com.cenaculo.model.ParamConsulta;
import br.com.cenaculo.util.FormatterGlobal;

/**
 * @author Priscila.Andersen
 *
 */
public class CabecalhoConverter {

	/**
	 * 
	 */
	public static Cabecalho convertJson(ResultSet rs, ParamConsulta param) {

		Cabecalho cabecalho = new Cabecalho();
		String horaI = (param.getHoraIni() != null || param.getHoraIni() == ""
				? param.getHoraIni()
				: "00:00");
		String horaF = (param.getHoraFim() != null || param.getHoraFim() == ""
				? param.getHoraFim()
				: "23:59");
		try {
			String dateTime = FormatterGlobal.converterBR(
					FormatterGlobal.converterUS(param.getDataIni())) + " "
					+ horaI + " ATE "
					+ FormatterGlobal.converterBR(
							FormatterGlobal.converterUS(param.getDataFim()))
					+ " " + horaF;
			cabecalho.setCidade(rs.getString("cidade"));
			cabecalho.setPos(new Integer(rs.getString("pos")));
			cabecalho.setEndereco(rs.getString("endereco"));
			cabecalho.setEstabelecimento(rs.getString("estabelecimento"));
			cabecalho.setDatetime(dateTime);

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return cabecalho;
	}

}
