/**
 * 
 */
package br.com.cenaculo.model;

/**
 * @author Priscila.Andersen
 *
 */
public class RecorrenciaCliente {

	private Integer umaCompra;
	private Integer duasCompras;
	private Integer tresOuMaisCompras;

	/**
	 * 
	 */
	public RecorrenciaCliente() {
		super();
	}

	/**
	 * @return the umaCompra
	 */
	public final Integer getUmaCompra() {
		return umaCompra;
	}

	/**
	 * @param umaCompra
	 *            the umaCompra to set
	 */
	public final void setUmaCompra(Integer umaCompra) {
		this.umaCompra = umaCompra;
	}

	/**
	 * @return the duasCompras
	 */
	public final Integer getDuasCompras() {
		return duasCompras;
	}

	/**
	 * @param duasCompras
	 *            the duasCompras to set
	 */
	public final void setDuasCompras(Integer duasCompras) {
		this.duasCompras = duasCompras;
	}

	/**
	 * @return the tresOuMaisCompras
	 */
	public final Integer getTresOuMaisCompras() {
		return tresOuMaisCompras;
	}

	/**
	 * @param tresOuMaisCompras
	 *            the tresOuMaisCompras to set
	 */
	public final void setTresOuMaisCompras(Integer tresOuMaisCompras) {
		this.tresOuMaisCompras = tresOuMaisCompras;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "RecorrenciaCliente [umaCompra=" + umaCompra + ", duasCompras="
				+ duasCompras + ", tresOuMaisCompras=" + tresOuMaisCompras
				+ "]";
	}

}
