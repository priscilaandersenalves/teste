USE [MPFPODB1]
GO

INSERT INTO [dbo].[acesso_mobile] ([idUsuario] ,[idLoja] ,[idEmpresa]  ,[senhaMobile]) VALUES (1 ,34000010,8,'teste')
INSERT INTO [dbo].[acesso_mobile] ([idUsuario] ,[idLoja] ,[idEmpresa]  ,[senhaMobile]) VALUES (1 ,34000011,9,'teste')
INSERT INTO [dbo].[acesso_mobile] ([idUsuario] ,[idLoja] ,[idEmpresa]  ,[senhaMobile]) VALUES (1 ,34000012,9,'teste')
INSERT INTO [dbo].[acesso_mobile] ([idUsuario] ,[idLoja] ,[idEmpresa]  ,[senhaMobile]) VALUES (1 ,34000013,10,'teste')

INSERT INTO [dbo].[acesso_mobile] ([idUsuario] ,[idLoja] ,[idEmpresa]  ,[senhaMobile]) VALUES (1 ,34000014,11,'teste')
INSERT INTO [dbo].[acesso_mobile] ([idUsuario] ,[idLoja] ,[idEmpresa]  ,[senhaMobile]) VALUES (1 ,34000015,12,'teste')
INSERT INTO [dbo].[acesso_mobile] ([idUsuario] ,[idLoja] ,[idEmpresa]  ,[senhaMobile]) VALUES (1 ,34000016,13,'teste')
GO
