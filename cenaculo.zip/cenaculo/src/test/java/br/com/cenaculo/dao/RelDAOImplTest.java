package br.com.cenaculo.dao;

import org.junit.Test;

import junit.framework.TestCase;

public class RelDAOImplTest extends TestCase {

	@Test
	public void testGetCabecalho() {

	}

	@Test
	public void testGetRelTotais() {

	}

	@Test
	public void testRelTransacao() {

	}

}
