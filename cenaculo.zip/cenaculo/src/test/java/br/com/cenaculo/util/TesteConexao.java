package br.com.cenaculo.util;

import org.junit.Assert;
import org.junit.Test;

import br.com.cenaculo.util.ConnectionFactory;

public class TesteConexao {

	@Test
	public void testGetConnection() {
		ConnectionFactory con = new ConnectionFactory();
		con.getConnection();

		Assert.assertTrue("Conexao Ativa", con != null ? true : false);
	}

	@Test
	public void testConectarSQL() {
		ConnectionFactory con = new ConnectionFactory();
		con.conectarSQL();

		Assert.assertTrue("Conexao Ativa", con != null ? true : false);
	}

}
