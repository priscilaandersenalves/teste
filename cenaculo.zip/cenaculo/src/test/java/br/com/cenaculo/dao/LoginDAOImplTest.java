/**
 * 
 */
package br.com.cenaculo.dao;

import org.junit.Test;

/**
 * @author Priscila.Andersen
 *
 */
public class LoginDAOImplTest {
	/**
	 * Test method for
	 * {@link br.com.cenaculo.dao.LoginDAOImpl#getAcessoMobile(br.com.cpsinformatica.model.ParamConsulta)}
	 * .
	 */
	@Test
	public void testGetAcessoMobile() {

	}

}
